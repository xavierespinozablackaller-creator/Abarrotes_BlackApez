﻿namespace Abarrotes_BlackApez
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            // crear y mostrar Form2 con los datos del formulario
            Form2 formulario2 = new Form2();

            // ocultar Form4
            this.Hide();

            // mostrar Form2
            formulario2.ShowDialog();

            // Regresar a Form1 cuando se cierre Form4
            this.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(
                   "Actualizado",
                   "Regresando a menu",
                   MessageBoxButtons.OK,
                   MessageBoxIcon.Exclamation);

            // crear y mostrar Form1 con los datos del formulario
            Form2 formulario2 = new Form2();

            // ocultar Form4
            this.Hide();

            // mostrar Form2
            formulario2.ShowDialog();

            // Regresar a Form2 cuando se cierre Form4
            this.Show();
        }
    }
}
