﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Abarrotes_BlackApez
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // crear y mostrar Form4 con los datos del formulario
            Form4 formulario4 = new Form4();

            // ocultar Form1
            this.Hide();

            // mostrar Form2
            formulario4.ShowDialog();

            // ir a Form4 cuando se cierre Form2
            this.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // crear y mostrar Form1 con los datos del formulario
            Form6 formulario6 = new Form6();

            // ocultar Form4
            this.Hide();

            // mostrar Form2
            formulario6.ShowDialog();

            // Regresar a Form1 cuando se cierre Form4
            this.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // crear y mostrar Form1 con los datos del formulario
            Form5 formulario5 = new Form5();

            // ocultar Form4
            this.Hide();

            // mostrar Form2
            formulario5.ShowDialog();

            // Regresar a Form1 cuando se cierre Form4
            this.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // crear y mostrar Form3 con los datos del formulario
            Form3 formulario3 = new Form3();

            // ocultar Form1
            this.Hide();

            // mostrar Form2
            formulario3.ShowDialog();

            // ir a Form3 cuando se cierre Form2
            this.Show();
        }
    }
}
