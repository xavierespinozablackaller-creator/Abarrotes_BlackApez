namespace Abarrotes_BlackApez
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Obtener informacion del formulario
            string id = textBox1.Text;
            string sucursal = textBox3.Text;
            string nombre = textBox2.Text;

            // validar que los campos no esten vacios
            if (string.IsNullOrEmpty(id) || 
                string.IsNullOrEmpty(sucursal) ||
                 string.IsNullOrEmpty(nombre) ||
                id == "ID:" ||
                sucursal == "Sucursal:" ||
                nombre == "Nombre:")
            {
                MessageBox.Show(
                    "Por favor, complete todos los campos.",
                    "Datos incompletos",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }
                // crear y mostrar Form2 con los datos del formulario
                 Form2 formulario2 = new Form2();

                  // ocultar Form1
                 this.Hide();

                 // mostrar Form2
                 formulario2.ShowDialog();

                 // Regresar a Form1 cuando se cierre Form2
                this.Show();
            
        }

        
    }
}
