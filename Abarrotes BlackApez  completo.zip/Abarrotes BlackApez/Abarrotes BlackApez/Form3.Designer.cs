﻿namespace Abarrotes_BlackApez
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            label1 = new Label();
            pictureBox1 = new PictureBox();
            label3 = new Label();
            panel1 = new Panel();
            label_pendientes = new Label();
            label_pedidos = new Label();
            label_listos = new Label();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.AliceBlue;
            label1.Font = new Font("Segoe UI", 14F);
            label1.ForeColor = SystemColors.ActiveCaptionText;
            label1.Location = new Point(67, 12);
            label1.Name = "label1";
            label1.Size = new Size(96, 25);
            label1.TabIndex = 0;
            label1.Text = "Empleado";
            label1.Click += label1_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(45, 50);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // label3
            // 
            label3.BackColor = Color.AliceBlue;
            label3.BorderStyle = BorderStyle.Fixed3D;
            label3.Font = new Font("Showcard Gothic", 50.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = SystemColors.Highlight;
            label3.Location = new Point(280, 91);
            label3.Name = "label3";
            label3.Size = new Size(240, 365);
            label3.TabIndex = 3;
            label3.Text = "ABAP";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            label3.Click += label3_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.AliceBlue;
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(2, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(214, 50);
            panel1.TabIndex = 4;
            // 
            // label_pendientes
            // 
            label_pendientes.AutoSize = true;
            label_pendientes.Font = new Font("Showcard Gothic", 20.25F);
            label_pendientes.Location = new Point(50, 53);
            label_pendientes.Name = "label_pendientes";
            label_pendientes.Size = new Size(175, 33);
            label_pendientes.TabIndex = 6;
            label_pendientes.Text = "PENDIENTES";
            label_pendientes.Click += label_pendientes_Click;
            // 
            // label_pedidos
            // 
            label_pedidos.AutoSize = true;
            label_pedidos.Font = new Font("Showcard Gothic", 20.25F);
            label_pedidos.Location = new Point(352, 53);
            label_pedidos.Name = "label_pedidos";
            label_pedidos.Size = new Size(132, 33);
            label_pedidos.TabIndex = 7;
            label_pedidos.Text = "PEDIDOS";
            label_pedidos.Click += label_pedidos_Click;
            // 
            // label_listos
            // 
            label_listos.AutoSize = true;
            label_listos.Font = new Font("Showcard Gothic", 20.25F);
            label_listos.Location = new Point(657, 53);
            label_listos.Name = "label_listos";
            label_listos.RightToLeft = RightToLeft.Yes;
            label_listos.Size = new Size(103, 33);
            label_listos.TabIndex = 8;
            label_listos.Text = "LISTOS";
            // 
            // button1
            // 
            button1.BackColor = Color.CornflowerBlue;
            button1.Font = new Font("Showcard Gothic", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.ForeColor = SystemColors.ControlLightLight;
            button1.Location = new Point(222, 0);
            button1.Name = "button1";
            button1.Size = new Size(208, 50);
            button1.TabIndex = 9;
            button1.Text = "PEDIDOS";
            button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            button2.BackColor = Color.CornflowerBlue;
            button2.Font = new Font("Showcard Gothic", 20.25F);
            button2.Location = new Point(424, 0);
            button2.Name = "button2";
            button2.Size = new Size(203, 50);
            button2.TabIndex = 10;
            button2.Text = "INVENTARIO";
            button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            button3.BackColor = Color.CornflowerBlue;
            button3.Font = new Font("Showcard Gothic", 20.25F);
            button3.Location = new Point(623, 0);
            button3.Name = "button3";
            button3.Size = new Size(178, 50);
            button3.TabIndex = 11;
            button3.Text = "VENTAS";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Font = new Font("Showcard Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button4.ForeColor = SystemColors.ActiveCaptionText;
            button4.Location = new Point(661, 413);
            button4.Name = "button4";
            button4.Size = new Size(140, 34);
            button4.TabIndex = 12;
            button4.Text = "REGRESAR";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.CornflowerBlue;
            ClientSize = new Size(800, 450);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label_listos);
            Controls.Add(label_pedidos);
            Controls.Add(label_pendientes);
            Controls.Add(panel1);
            Controls.Add(label3);
            ForeColor = SystemColors.ControlLightLight;
            Name = "Form3";
            Text = "Form3";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private PictureBox pictureBox1;
        private Label label3;
        private Panel panel1;
        private Label label_pendientes;
        private Label label_pedidos;
        private Label label_listos;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
    }
}