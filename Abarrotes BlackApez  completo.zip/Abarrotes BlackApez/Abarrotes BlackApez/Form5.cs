﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Abarrotes_BlackApez
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(
                    "Actualizado",
                    "Regresando a menu",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Exclamation);

            // crear y mostrar Form2 con los datos del formulario
            Form2 formulario2 = new Form2();

            // ocultar Form5
            this.Hide();

            // mostrar Form2
            formulario2.ShowDialog();

            // Regresar a Form2 cuando se cierre Form5
            this.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // crear y mostrar Form1 con los datos del formulario
            Form2 formulario2 = new Form2();

            // ocultar Form4
            this.Hide();

            // mostrar Form2
            formulario2.ShowDialog();

            // Regresar a Form1 cuando se cierre Form4
            this.Show();
        }
    }
}
