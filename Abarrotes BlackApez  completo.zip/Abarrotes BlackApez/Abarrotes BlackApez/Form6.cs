﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Abarrotes_BlackApez
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(
                   "Actualizado",
                   "Regresando a menu",
                   MessageBoxButtons.OK,
                   MessageBoxIcon.Exclamation);

            // crear y mostrar Form2 con los datos del formulario
            Form2 formulario2 = new Form2();

            // ocultar Form6
            this.Hide();

            // mostrar Form2
            formulario2.ShowDialog();

            // Regresar a Form2 cuando se cierre Form6
            this.Show();
        }
    }
}
